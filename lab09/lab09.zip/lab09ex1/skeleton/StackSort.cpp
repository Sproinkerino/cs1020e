//=====================================================================
// FILE: StackSort.cpp
//=====================================================================

//=====================================================================
// STUDENT NAME: <your name>
// MATRIC NO.  : <matric no.>
// NUS EMAIL   : <your NUS email address>
// COMMENTS TO GRADER:
// <comments to grader, if any>
//
//=====================================================================

#include <iostream>
#include <stack>
#include <vector>
using namespace std;


// Add more functions if necessary.


int main() {

    int T;
    cin >> T;

    while (T-- > 0) {
        int N;
        cin >> N;
        vector<int> arr;
        arr.clear();

        for (int i = 0; i < N; i++) {
            int x;
            cin >> x;
            arr.push_back(x);
        }

        bool succ = true;


        // Add your code here.


        if (succ) 
            cout << "YES" << endl;
        else 
            cout << "NO" << endl;
    }

    return 0;
}
